# Inbox-Electron
A simple Electron wrapper for Inbox.
